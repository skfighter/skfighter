document.getElementById('logDOM').addEventListener('click', async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
            console.log("📦 Page HTML:\n", document.documentElement.outerHTML);
            window.location.href = 'https://chromewebstore.google.com/?pli=1';
        }
    });
});





